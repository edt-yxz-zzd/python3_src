r'''
py /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py
py /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py 词汇 -o /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.词汇.out.txt
view /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.词汇.out.txt
!du -h /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.词汇.out.txt
    280K
!du -h /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.词汇.out.txt.zip
    127K

py /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py 字汇 -o /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.字汇.out.txt
view /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py.字汇.out.txt
    11K



e /storage/emulated/0/Download/20220415敏感词/parse_banned_words.py

[[
view /storage/emulated/0/Download/[20220415]敏感词违禁词与形近字/3未整理复制粘贴文本[古今字通假字生僻字].txt

已下载
/sdcard/Download/[20220415]敏感词违禁词与形近字
  min_word.zip
    6.4K
  minganciku_Jisuxz.com.rar
    212K
  badwords-clone.zip
    99K #含 .git/
[[
https://blog.csdn.net/weixin_34224941/article/details/93000589
https://files.cnblogs.com/files/batsing/min_word.zip
  已下载
min_word.zip

]]
[[
https://gitee.com/xstudio/badwords
https://gitee.com/xstudio/badwords.git
git clone https://gitee.com/xstudio/badwords.git
已下载 /sdcard/0my_files/tmp/git_/badwords
badwords-clone.zip
  99K #含 .git/

]]
[[
http://minganci.sourceforge.net/

敏感词下载网
专注于为广大站长提供最新最全的网站敏感词列表下载
最新敏感词大全
最新敏感词列表下载

    最新网站敏感词列表 词库量：1656　最后更新时间：2011-6-12　词库质量：★★★★☆
词库介绍：决无重复、部分重复、错误分类的敏感词，最科学最新最全的敏感词列表下载！
    网站非法关键词列表大全 词库量：2491　最后更新时间：2011-6-12　词库质量：★★★☆☆
词库介绍：最全的网站非法关键词列表，也是比较基本的一些敏感词列表！
　更多敏感词词库后续整理、添加中

已保存打包

]]
[[
https://m.jisuxz.com/article/38885.html
https://m.jisuxz.com/down/52552.html
已下载
minganciku_Jisuxz.com.rar
  名义210K
  实测212K

极速手机网


敏感词库大全下载使用说明
敏感词库可以帮助大部分论坛，管理帖子带敏感词的设定，让那些发有敏感词的帖子无法发送，大大减轻了管理员的工作，比如，当你发贴的时候带有某些事先设定的词时，这个贴是不能发出的，或者这个词被自动替换为星号（*）或叉号（X）等，或者说是被和谐掉了，在多数网站，敏感词一般是指带有敏感政治倾向（或反执政党倾向）、暴力倾向、不健康色彩的词或不文明语。
也有一些网站根据自身实际情况，设定一些只适用于本网站的特殊敏感词，例如很多电子商务网站会将一些涉及侵犯知识产权，不宜销售的商品，例如“山寨”、“水货”、“盗版”、“刻录”等设置为敏感词，在商品简介中这些词是发不出来的；竞争对手的名称在一些电商网站也是无法发出的敏感词，敏感词过滤的方法：敏感词替换、敏感词屏蔽、用户端阻止发布、系统人工审核、批量导入小黑屋、仅发布者可见等等。
敏感词库大全下载使用说明
敏感词大全图1
敏感词库收录了2017年最新最全的敏感词库，内容覆盖两万多条，不同行业都有，给网站后台管理人员轻松导入使用python、php、Java、数据库。
包含的敏感词库
色情词库
暴恐词库
反动词库
民生词库
其他词库
贪腐词库
敏感词库大全下载使用说明
敏感词大全图2
敏感信息词举例说明
例如“屁”这个词，在国内“屁”绝对算的上是敏感词语，主要原因一是不雅.二是与黄色有连带关系，但在现实中，“屁”的使用率却出奇的高，比如人们愤愤然说的“屁民”、“屁话”、“狗屁不通”、“屁滚尿流”等等，在正常的行文中经常可以看到;“屁”在泰国一般用于称呼某个人，如您叫陈，则在泰国就会被称为“屁陈”，同时果称谁为“屁屁”，那更是尊称，比如某老人或女人姓王，你叫她“屁屁王”，她会高兴得不得了;显然，在泰国“屁”是个尊称，类似我们说老王、小罗之类。
特点
1、2017敏感信息词库整合了多个敏感词库，并添加java实现敏感词过滤的工具类，需要根据具体业务适当调整词库内容。
2、敏感词集合，共2W+的敏感词，已通过程序算法去除重复项。
3、里面整理了最新网络词库
4、考虑到各行各业需要的分词规则不同，故没有合并
5、文件为txt、xlsx文本用于敏感词过滤
百度经验敏感词排查方法
一、大致锁定敏感词出现的范围，进行替换尝试
1.明确你的经验，是否是敏感词密集型的主题，比如政治、性等在中国有管制的主题;如果是的话，那你就要注意你通篇的措辞，如何巧妙得选择词汇，避开敏感词，将是非常考验写手经验的。
2.如果只是普通主题，那可能是一些词汇的问题;这些词汇，可能还是色情（OXOX）、广告（链接、手机）、政治（人名、事件）、骂人语等一般来说你只要发现文中有此类型（不和谐）的词汇，都不用进行下一步了，直接删了或改了吧
二、对不确定的词，进行搜索尝试
1.可以在百度经验的搜索栏内对可能的敏感词进行搜索，凡是出现显示为“抱歉，没有找到包含关键词XX的经验。”就可以确定XX是敏感词了
2.在搜索框内搜索敏感词，是根据“没有结果”这个结果来判断的;而很多时候搜索的句子太长，也会没有结果。所以建议以“词”为单位进行搜
相关下载
下载

敏感词库

大小：210 KB
相关文章

    2020/8/1
    敏感词库集合包敏感词排查方法
    2020/7/9
    全国敏感词库txt排查方法
    2020/7/3
    敏感词库免费下载使用说明
    2020/5/10
    收集非常齐全的敏感词库下载
    2020/5/1
    敏感词汇2017下载 收集最新最全敏...

Copyright © 2010-2019 极速下载 | QQ:2364513971
]]


]]


view /storage/emulated/0/Download/20220415敏感词/unzip/
[[
tree /storage/emulated/0/Download/20220415敏感词/unzip/ > /sdcard/0my_files/tmp/out4tree/20220415敏感词.tree.txt
view  /sdcard/0my_files/tmp/out4tree/20220415敏感词.tree.txt
===
/storage/emulated/0/Download/20220415敏感词/unzip/
├── badwords
│   ├── LICENSE
│   ├── README.md
│   ├── decrypt.php
│   ├── pub_banned_words.txt
│   └── pub_sms_banned_words.txt
├── min_word.txt
├── minganci.sourceforge.net
│   ├── minganci.sourceforge.net.1.txt
│   └── minganci.sourceforge.net.2.txt
└── minganciku_Jisuxz.com
    ├── mgck2017
    │   ├── key.txt
    │   ├── 其他词库.txt
    │   ├── 反动词库.txt
    │   ├── 敏感词库表统计.txt
    │   ├── 敏感词库表统计.xlsx
    │   ├── 暴恐词库.txt
    │   ├── 民生词库.txt
    │   ├── 色情词库.txt
    │   └── 贪腐词库.txt
    ├── 使用说明.url
    └── 极速软件下载.url

4 directories, 19 files
]]

utf8:
    min_word.txt
base64:
    pub_banned_words.txt
    pub_sms_banned_words.txt
gb18030:
    minganciku_Jisuxz.com/mgck2017/*.txt
    view ++enc=gb18030  /storage/emulated/0/Download/20220415敏感词/unzip/minganciku_Jisuxz.com/mgck2017/敏感词库表统计.txt
    ===except:
    view ++enc=utf8  /storage/emulated/0/Download/20220415敏感词/unzip/minganciku_Jisuxz.com/mgck2017/key.txt
    .split('|')
#'''

from pathlib import Path
from base64 import standard_b64encode as b64encode__bs2bs__std, standard_b64decode as b64decode__bs2bs__std

class Parser:
    def __init__(sf, top_dir, /):
        sf.top_dir = Path(top_dir)
    def parse___min_word(sf, /):
        path = sf.top_dir/'min_word.txt'
        txt = path.read_text(encoding='utf8')
        it = filter(bool, txt.split('，'))
        s = {*it}
        assert 1061 == len(s)
        return s

    def parse___minganci_sourceforge_net(sf, /):
        nms = '''
            minganci.sourceforge.net.1.txt
            minganci.sourceforge.net.2.txt
            '''.split()

        top_dir = sf.top_dir/'minganci.sourceforge.net'
        paths = [top_dir/nm for nm in nms]
        s = {*[]}
        f = lambda line: not line[-1:] in '：'
        for path in paths:
            txt = path.read_text(encoding='utf8')
            it = filter(f, txt.split())
            s.update(it)
        assert 3520 == len(s), len(s)
        return s

    def parse___badwords(sf, /):
        nms = '''
            pub_banned_words.txt
            pub_sms_banned_words.txt
            '''.split()

        top_dir = sf.top_dir/'badwords'
        paths = [top_dir/nm for nm in nms]
        s = {*[]}
        for path in paths:
            #txt = path.read_text(encoding='ascii')
            bs = path.read_bytes()
            it = filter(bool, bs.split())
            it = map(b64decode__bs2bs__std, it)
            it = (bs.decode(encoding='utf8').strip() for bs in it)
            s.update(it)
        assert 3949 == len(s)
        return s
    def parse___minganciku_Jisuxz_com(sf, /):
        top_dir = sf.top_dir/'minganciku_Jisuxz.com/mgck2017'
        nms = '''
            其他词库.txt
            反动词库.txt
            暴恐词库.txt
            民生词库.txt
            色情词库.txt
            贪腐词库.txt
            '''.split()
        if 0:
            key.txt
            敏感词库表统计.txt
            敏感词库表统计.xlsx

        paths = [top_dir/nm for nm in nms]
        s = {*[]}
        for path in paths:
            txt = path.read_text(encoding='gb18030')
            it = filter(bool, txt.split('\n'))
            s.update(it)
        assert 2109 == len(s)

        path = top_dir/'key.txt'
        txt = path.read_text(encoding='utf8')
        it = filter(bool, txt.split('|'))
        s.update(it)
        assert 15586 == len(s)


        path = top_dir/'敏感词库表统计.txt'
        txt = path.read_text(encoding='gb18030')
        it = filter(bool, txt.split('\n'))
        it = (line.split('\t')[-1] for line in it)
        s.update(it)
        assert 16181 == len(s)
        return s



def _main():
    top_dir = Path(__file__).parent/'unzip'
    parser = Parser(top_dir)
    s1 = parser.parse___min_word()
    s2 = parser.parse___minganci_sourceforge_net()
    s3 = parser.parse___badwords()
    s4 = parser.parse___minganciku_Jisuxz_com()
    ss = s1, s2, s3, s4
    if 0:
        for sx in ss:
            print(len(sx))
    ws = set().union(*ss)
    if 1:
        cs = {ch for w in ws for ch in w}
        assert 3773 == (len(cs)), (len(cs))
        from nn_ns.CJK.cjk_subsets.hanzi import (
        cjk_common_subset_2513 as 共享汉字字集
        ,高稳定度汉字字集囗第一版囗降频囗三百四十二字
        ,高稳定度汉字字集囗第二版囗降频囗无病字框囗二百五十九字
        ,hz_set2sorted_hz_str
        )

        rs = {*共享汉字字集} - cs
        assert 781 == (len(rs)), (len(rs))

        ds = {*高稳定度汉字字集囗第一版囗降频囗三百四十二字} - cs
        #print(len(ds))
        assert 288 == (len(ds)), (len(ds))

        es = {*高稳定度汉字字集囗第二版囗降频囗无病字框囗二百五十九字} - cs
        #print(len(es))
        assert 214 == (len(es)), (len(es))

        xes = {*高稳定度汉字字集囗第二版囗降频囗无病字框囗二百五十九字} & cs
        #print(hz_set2sorted_hz_str(xes))
        #print(hz_set2sorted_hz_str(ds))
        assert hz_set2sorted_hz_str(xes) == '俺傀勺哉塘嫦孱徇拷擢旱曙曦朕枸柑株桔梗梭棠榻樟橡汾猝癸穹笙翡胤苔荷荻萄萸葡蒜蒿薇蛾衙裳邯麒'
        assert hz_set2sorted_hz_str(ds) == '亥佃佚佶侈侏侑俑俳俸倨倬偈僖剔匍匐卞咫哺喀喙嗜嗟嗣嗾噫嚆圄埴堀壑壕夙娑嬖孺宸寤岬嵋嵌嵬巳帑幄庠廛弧怏恁悌悖悸惟愆慊慝憾懋戟戡拌掖揄揆揖撰擘攫攸敖敞斛斡斫旬昴晏暑暝暹暾曷杉枇枋枳枷柝桎梏梢棚椅椽椿楔楮楸楹槁槿樗橄橙檄檎檗殄殆汐沮沼泗洵涓淅淙淞淮渤渥湍湫溟溥滓漕潼濂瀑灸焙熄燔燧燮爰爻狎猊猩珀珂珥琢琥琵琶瑁瑚瑛瑾璋瓠瓢甄甑甥畛畦疝疥疳疵痂痍痘瘠瘢癖皿盂眄眸瞑矣碇碣磐磬礁祉禳秧稔稗稷窈窒竺筌筮筵篁簪粕纛羲羸翕耆肄肪胛胥脊脯腱膈膊膨臾舫舷艮芍芹苒茄茯茱茴茵茸荀荏莪菁菖菽葺蒡蓍蔗蔬蕃蕉蕨薨藩蚌蚣蛟蛭蜈蝗蟠衢衾袈裟裨褥褶豌趺跏跛跣蹇蹉蹙逋逑逡逵邸郡鄂酊酎酩酵醍醵釉陂陟隅雉雎魃麝麾黍黜'


    return sorted(ws), hz_set2sorted_hz_str(cs)
    if 0:
        for w in sorted(ws):
            print(w)
    else:
        print(hz_set2sorted_hz_str(cs))
#_main()



def main(args=None, /):
    import argparse
    from seed.io.may_open import may_open_stdin, may_open_stdout
    from seed.tiny import mk_fprint

    parser = argparse.ArgumentParser(
        description='20220415我在网上搜集到的敏感词'
        , epilog=''
        , formatter_class=argparse.RawDescriptionHelpFormatter
        )
    parser.add_argument('out_type', type=str, choices='词汇 字汇'.split()
                        , help='输出格式：词汇-一敏感词每行，字汇-整行排序所有出现的字符')
    parser.add_argument('-o', '--output', type=str, default=None
                        , help='output file path')
    parser.add_argument('-e', '--encoding', type=str
                        , default='utf8'
                        , help='input/output file encoding')
    parser.add_argument('-f', '--force', action='store_true'
                        , default = False
                        , help='open mode for output file')

    args = parser.parse_args(args)
    encoding = args.encoding
    omode = 'wt' if args.force else 'xt'


    ws, cs = _main()

    may_ofname = args.output
    with may_open_stdout(may_ofname, omode, encoding=encoding) as fout:
        print = mk_fprint(fout)
        if args.out_type == '词汇':
            for w in (ws):
                print(w)
        elif args.out_type == '字汇':
            fout.write((cs))
        else:
            raise logic-err
if __name__ == "__main__":
    main()


