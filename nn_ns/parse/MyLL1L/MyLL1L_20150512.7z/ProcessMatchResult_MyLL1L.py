from ProcessParseResult import ProcessMatchResult
from MatchResultExplain_MyLL1L import MatchResultExplain_MyLL1L

class ProcessMatchResult_MyLL1L(ProcessMatchResult):
    def __init__(self, tIDDict, tokens):
        self.tIDDict, self.tokens = tIDDict, tokens
        
        f = lambda r: MatchResultExplain_MyLL1L(r, self.tIDDict, tokens)
        super().__init__(f)
        return
    
    
    
    
        

        
