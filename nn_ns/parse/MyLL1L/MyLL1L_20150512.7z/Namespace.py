class Namespace:
    def __lshift__(self, ns):
        assert isinstance(ns, Namespace)
        self.__dict__ = ns.__dict__
    def __eq__(self, other):
        return self.__dict__ == other.__dict__
    def __ne__(self, other):
        return not (self.__dict__ == other.__dict__)
    def __repr__(self):
        return '<{!r}>'.format(self.__dict__)
'''
a = Namespace()
b = Namespace()
a << b
b.afass = ''
print(a)
assert a == b
'''
