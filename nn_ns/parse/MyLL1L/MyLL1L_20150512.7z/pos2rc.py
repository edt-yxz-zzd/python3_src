from bisect import bisect_left


def calcLineBeginPos(string):
    i = -1
    ls = []
    while True:
        i += 1
        ls.append(i)
        
        i = string.find('\n', i)
        if i == -1:
            break

    return ls
class Pos2RC:
    def __init__(self, string):
        self.ls = calcLineBeginPos(string)

    def __call__(self, pos):
        lineno = bisect_left(self.ls, pos)
        col = pos - self.ls[lineno]
        return lineno, col

    
            
            
