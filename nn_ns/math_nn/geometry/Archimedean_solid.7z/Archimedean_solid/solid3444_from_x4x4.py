

from nn_ns.graph.show_v2neighbors import show_v2neighbors
embedding = [(1,2,3,4), (0,12,6), (0,6,8),
             (0,8,10), (0,10,12), (12,13,6),
             (1,5,7,2), (6,13,8), (2,7,9,3),
             (8,13,10), (3,9,11,4), (10,13,12),
             (1,4,11,5), (5,11,9,7)]


show_v2neighbors(embedding)





