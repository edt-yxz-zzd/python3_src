#if !defined HAVE_BYTESCAN_H__
#define      HAVE_BYTESCAN_H__
// This file is part of the FXT library.
// Copyright (C) 2010, 2012 Joerg Arndt
// License: GNU General Public License version 3 or later,
// see the file COPYING.txt in the main directory.

#include "fxttypes.h"

// aux1/bytescan.cc:
ulong long_strlen(const char *str);


#endif  //  !defined HAVE_BYTESCAN_H__
