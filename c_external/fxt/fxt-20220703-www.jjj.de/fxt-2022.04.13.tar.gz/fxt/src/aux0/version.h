#if !defined  HAVE_VERSION_H__
#define       HAVE_VERSION_H__
// This file is part of the FXT library.
// Copyright (C) 2010 Joerg Arndt
// License: GNU General Public License version 3 or later,
// see the file COPYING.txt in the main directory.


// aux0/version.cc:
void print_fxt_version();


#endif  // !defined HAVE_VERSION_H__
