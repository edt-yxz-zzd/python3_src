#if !defined HAVE_PRINT_FIXED_H__
#define      HAVE_PRINT_FIXED_H__
// This file is part of the FXT library.
// Copyright (C) 2010, 2011 Joerg Arndt
// License: GNU General Public License version 3 or later,
// see the file COPYING.txt in the main directory.

// aux0/print-fixed.cc:
void print_fixed(const char *bla, double v, long nd, bool sq);


#endif  // !defined HAVE_PRINT_FIXED_H__
